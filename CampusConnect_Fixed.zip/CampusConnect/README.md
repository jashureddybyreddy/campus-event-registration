# CampusConnect — UPI and Email OTP fixes

A runnable Flask campus event application, including the missing HTML templates, the supplied database and automated regression tests. Direct UPI payments require manual organizer verification against the bank statement.

## Start on Windows

1. Extract the ZIP and open a terminal inside the `CampusConnect` folder.
2. Install Python 3.10 or later, then run:

```powershell
python -m venv venv
.\venv\Scripts\activate
python -m pip install -r requirements.txt
python setup_config.py
python app.py
```

Open http://127.0.0.1:5001.

On Linux/macOS, activate with `source venv/bin/activate`.

## Enter your own UPI ID and email app password

`python setup_config.py` asks for:

- Sender Gmail address: the mailbox that will send OTP emails.
- Email **app password**: entered with hidden input. Spaces are removed automatically.
- Your own UPI ID, for example `yourname@yourbank`.
- Payee name as shown for your bank account.

The email app password belongs to the **same Gmail account as the sender address**. Use an app password issued by your email provider, not your regular sign-in password. Never paste it into chat or HTML templates. Gmail account help: https://support.google.com/accounts/answer/185833.

The setup saves email configuration in your private `.env` and UPI details in the local database. Restart the app after changing `.env`. You can also copy `.env.example` to `.env` and fill it manually; configure UPI details through Admin > Settings. `OTP_EMAIL` and `OTP_APP_PASSWORD` are retained for compatibility with your original app. Other providers may use `SMTP_SECURITY=starttls` and `SMTP_PORT=587` with their own `SMTP_HOST`.

Check configuration:

```powershell
python check_setup.py
```

Send a test message **to your own configured sender address**:

```powershell
python check_setup.py --send-test
```

This checks SMTP acceptance; confirm the message appears in your inbox or spam folder. Real email delivery has not been tested in this package because your credentials were not supplied.

## Use the app

Existing demo logins from the source project:

| Role | Email | Password |
| --- | --- | --- |
| Student | student@campusconnect.edu | Student@123 |
| Organizer | organizer@campusconnect.edu | Organizer@123 |
| Administrator | admin@campusconnect.edu | Admin@123 |

Your existing uploaded database is included, so existing changes to those account passwords remain in effect. These are local demonstration accounts; replace default credentials and configure real user/administrator accounts before public use. Passwords in the database are hashed.

1. Configure UPI and email with `setup_config.py`.
2. Sign in as administrator to review Settings, then sign out.
3. Create a new student account with a real email address.
4. Enter the OTP from that inbox. The app never displays the OTP on screen.
5. Register for a free event to receive an entry pass immediately.
6. Register for a paid event, scan the QR or open the UPI app link, verify the payee and complete payment.
7. Submit the actual transaction reference and an optional receipt.
8. The event organizer reviews the bank statement and approves or rejects the payment.
9. Organizers can enter a ticket code, booking reference or scanned QR text to mark attendance. Students with confirmed attendance can print a participation certificate.
10. Refund payouts happen manually in the banking app; staff record the completed payout reference afterward.

UPI payments are not automatically verified. A QR code or receipt screenshot alone is not proof that money arrived. Ticket QR codes contain a ticket identifier; they are not encrypted and require a confirmed database registration at check-in. Camera scanning is not bundled; a scanner can paste/type the QR contents into the attendance field.

## OTP troubleshooting

- Missing settings or SMTP errors show a delivery-failure message; the app does not pretend an email was sent.
- Check the sender address, app password, inbox/spam folder, provider SMTP settings and network access.
- Codes expire after 10 minutes, using UTC consistently across Python and SQLite.
- Wait 60 seconds before resending. There are at most 10 successfully issued codes per email per hour.
- Five incorrect attempts lock that code. Request a new code after the cooldown.
- A successful resend invalidates the previous code; a failed resend keeps the previous valid code usable.
- Signup codes cannot authorize password reset, and codes work only once.
- Reset authorization expires after 10 minutes.
- Existing plaintext OTPs from the supplied database are deleted during migration. Request a new code after upgrading.
- A persistent session secret is generated automatically when `FLASK_SECRET_KEY` is blank. Keep `.env` and `.session_secret` private. Changing the secret invalidates sessions and pending OTPs.

## Files and existing data

The supplied database is retained and migrated in place; tests use temporary databases. One uploaded database record references a receipt file, but no receipt files were supplied. That historical receipt cannot be displayed until the matching original file is restored in `uploads/receipts/`. Newly uploaded receipts work normally.

The ZIP includes application source, 19 templates, setup tools, tests and your database. The packager excludes private `.env`, generated session secrets, virtual environments, caches and receipts. Back up the database and receipts separately before moving an existing installation. This ZIP is a local development deliverable, not a public deployment security certification.

## Test and rebuild

```powershell
python -m unittest discover -p "test_*.py" -v
python make_zip.py
```

See `TEST_REPORT.md` for verification coverage and limits. Debug mode is off by default. For public hosting, use HTTPS, set `COOKIE_SECURE=true`, configure a private `FLASK_SECRET_KEY`, replace demo credentials and use a production WSGI server rather than Flask's development server.
