# Verification report

Verified: 28 October 2026.

## Result

**31 automated tests passed** on Python 3.12 with Flask 3.1.3. Tests use temporary databases and receipt folders, not the supplied project database. No real emails, UPI transfers or refunds were performed.

Run from the extracted CampusConnect directory:

```bash
python -m unittest discover -p "test_*.py" -v
```

## Coverage

- Original seven integration checks: health, event discovery, role logins, UPI settings, free registration, paid registration/approval and duplicate UTR blocking.
- OTP hashing, purpose binding, expiry, five-attempt limit, single use, resend cooldown, previous-code invalidation, failed resend preservation and hourly issuance limit.
- Signup and email verification through Flask routes without exposing OTPs in HTML.
- Password reset and expiry of reset authorization.
- Mock SMTP SSL, STARTTLS, authentication failure, missing credentials and app-password space removal.
- Setup script saves the chosen sender, app password, UPI ID and payee name.
- CSRF enforcement with real hidden-form tokens.
- Render checks for public, student, organizer and administrator pages.
- Seat-hold release exactly once, late payment submission, sold-out resolution routing and concurrent reservations for the last seat.
- Repeated rejection does not increase seats; rejected/unsubmitted payments cannot be approved.
- Receipt content validation rejects an HTML file disguised as an image.
- Attendance from QR text, participation certificate, refund request/processing and invalidation of refunded tickets.
- Invalid configuration/event inputs and payment QR authorization.
- Unrelated organizers cannot access another event's payment page or UPI QR.

## Other checks

- Python compilation succeeded.
- SQLite integrity check returned `ok`; foreign-key integrity checked while packaging.
- ZIP integrity, expected templates and exclusion of credentials/caches verified.

## Remaining external checks

- Actual SMTP delivery needs the owner's sender address and app password. Run `python check_setup.py --send-test` locally, then verify a new signup and reset email in a real inbox.
- Actual UPI payment must be checked in a real payment app and the receiving bank statement. Manual organizer approval remains required.
- The uploaded database references one historical receipt whose file was not uploaded. Its bytes cannot be reconstructed; restore the original receipt to display it.
- Browser rendering was checked through server-side template responses; this report does not claim cross-browser visual or mobile UPI-app testing.
- The package is suitable for local testing. It is not a complete public-hosting security audit.
