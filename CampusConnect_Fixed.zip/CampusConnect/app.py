import os
import io
import time
import uuid
import smtplib
import sqlite3
import secrets
import re
import hmac
from urllib.parse import urlencode, urlsplit
from dotenv import load_dotenv
from datetime import datetime, timedelta, timezone
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, session, send_file, abort, jsonify
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import qrcode

load_dotenv(Path(__file__).resolve().parent / ".env")
import database
import otp_service

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads" / "receipts"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "pdf"}
MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5 MB

app = Flask(__name__)
secret_path = BASE_DIR / ".session_secret"
if not os.environ.get("FLASK_SECRET_KEY"):
    try:
        fd = os.open(secret_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as secret_file:
            secret_file.write(secrets.token_hex(32))
    except FileExistsError:
        pass
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or secret_path.read_text().strip()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "false").lower() == "true",
                  WTF_CSRF_ENABLED=True)

@app.before_request
def protect_requests():
    if request.method == "POST" and app.config.get("WTF_CSRF_ENABLED", True):
        supplied = request.form.get("csrf_token", "")
        expected = session.get("csrf_token", "")
        if not supplied or not expected or not hmac.compare_digest(supplied, expected):
            abort(400, "Form expired. Reload the page and try again.")

def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]

app.jinja_env.globals["csrf_token"] = csrf_token

app.config["UPLOAD_FOLDER"] = UPLOAD_DIR
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

@app.after_request
def response_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "same-origin"
    if session.get("user_id") or request.endpoint in ("verify_otp", "reset_password"):
        response.headers["Cache-Control"] = "no-store"
    return response

@app.errorhandler(413)
def too_large(error):
    return "Upload too large. Maximum receipt size is 5 MB. Go back and choose a smaller file.", 413

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

# ==========================================
# AUTHENTICATION & ROLE DECORATORS
# ==========================================

def get_current_user():
    if "user_id" not in session:
        return None
    conn = database.get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    conn.close()
    return user

def can_access_registration(reg, user):
    if reg["student_id"] == user["id"] or user["role"] == "admin":
        return True
    if user["role"] != "organizer":
        return False
    conn = database.get_db_connection()
    event = conn.execute("SELECT organizer_id FROM events WHERE id=?", (reg["event_id"],)).fetchone()
    conn.close()
    return bool(event and event["organizer_id"] == user["id"])

@app.context_processor
def inject_context():
    user = get_current_user()
    college_upi_id = database.get_setting("college_upi_id", "campusconnect@upi")
    payee_name = database.get_setting("payee_name", "CampusConnect Events College Fund")
    support_email = database.get_setting("support_email", "payments@campusconnect.edu")
    support_phone = database.get_setting("support_phone", "+91 98765 43210")
    return {
        "current_user": user,
        "college_upi_id": college_upi_id,
        "payee_name": payee_name,
        "support_email": support_email,
        "support_phone": support_phone,
        "now": datetime.now(timezone.utc).replace(tzinfo=None)
    }

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please sign in to access this page.", "warning")
            return redirect(url_for("login", next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def organizer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user or user["role"] not in ("organizer", "admin"):
            flash("Access restricted to event organizers and administrators.", "danger")
            return redirect(url_for("home"))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user or user["role"] != "admin":
            flash("Access restricted to system administrators.", "danger")
            return redirect(url_for("home"))
        return f(*args, **kwargs)
    return decorated_function

# ==========================================
# HELPER FUNCTIONS: EMAIL & OTP
# ==========================================

def send_email_notification(to_email, subject, body_html):
    return otp_service.send_email(to_email, subject, body_html)

def generate_and_save_otp(email, purpose):
    session.pop("otp_verified_for_reset", None)
    session.pop("reset_verified_at", None)
    session["pending_verification_email"] = email
    session["pending_verification_purpose"] = purpose
    ok, message = otp_service.issue(email, purpose, app.secret_key)
    flash(message, "info" if ok else "warning")
    return ok

def expire_holds():
    conn = database.get_db_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        expired = conn.execute("SELECT id, event_id FROM registrations WHERE status='Awaiting payment' AND seat_hold_expires_at <= datetime('now')").fetchall()
        for row in expired:
            conn.execute("UPDATE registrations SET status='Expired' WHERE id=?", (row["id"],))
            conn.execute("UPDATE events SET available_seats=available_seats+1 WHERE id=?", (row["event_id"],))
        conn.commit()
    finally:
        conn.close()

# ==========================================
# PUBLIC ROUTES & EVENT DISCOVERY
# ==========================================

@app.route("/")
def home():
    expire_holds()
    category = request.args.get("category", "")
    filter_type = request.args.get("type", "all") # all, free, paid, upcoming, past
    search = request.args.get("q", "").strip()

    conn = database.get_db_connection()
    query = "SELECT e.*, u.name as organizer_name FROM events e JOIN users u ON e.organizer_id = u.id WHERE e.is_active = 1"
    params = []

    if category:
        query += " AND e.category = ?"
        params.append(category)

    if filter_type == "free":
        query += " AND e.fee = 0"
    elif filter_type == "paid":
        query += " AND e.fee > 0"
    elif filter_type == "upcoming":
        query += " AND date(e.event_date) >= date('now')"
    elif filter_type == "past":
        query += " AND date(e.event_date) < date('now')"

    if search:
        query += " AND (e.title LIKE ? OR e.description LIKE ? OR e.venue LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])

    query += " ORDER BY e.event_date ASC"
    events = conn.execute(query, params).fetchall()

    categories = conn.execute("SELECT DISTINCT category FROM events WHERE is_active = 1 ORDER BY category").fetchall()
    conn.close()

    return render_template("index.html", events=events, categories=categories, current_filter=filter_type, current_category=category, search_query=search)

@app.route("/event/<int:event_id>")
def event_detail(event_id):
    conn = database.get_db_connection()
    event = conn.execute("""
        SELECT e.*, u.name as organizer_name, u.email as organizer_email, u.department as organizer_dept
        FROM events e
        JOIN users u ON e.organizer_id = u.id
        WHERE e.id = ?
    """, (event_id,)).fetchone()

    if not event:
        conn.close()
        flash("Event not found.", "danger")
        return redirect(url_for("home"))

    user_reg = None
    if "user_id" in session:
        user_reg = conn.execute("""
            SELECT * FROM registrations WHERE student_id = ? AND event_id = ? ORDER BY id DESC LIMIT 1
        """, (session["user_id"], event_id)).fetchone()

    conn.close()
    return render_template("event_detail.html", event=event, user_reg=user_reg)

@app.route("/health")
def health():
    return {
        "status": "ok",
        "application": "CampusConnect",
        "payment_gateway": "Direct UPI (Manual Verification)",
        "razorpay_integrated": False,
        "timestamp": datetime.now(timezone.utc).replace(tzinfo=None).isoformat()
    }

# ==========================================
# AUTHENTICATION ROUTES
# ==========================================

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        department = request.form.get("department", "").strip()
        year = request.form.get("year", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not name or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email) or not phone or not password:
            flash("Please fill in all required fields.", "danger")
            return render_template("signup.html")

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template("signup.html")

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return render_template("signup.html")

        conn = database.get_db_connection()
        existing = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
        if existing:
            conn.close()
            flash("An account with this email already exists. Please sign in.", "warning")
            return redirect(url_for("login"))

        password_hash = generate_password_hash(password)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO users (name, email, phone, department, year, role, password_hash, email_verified)
            VALUES (?, ?, ?, ?, ?, 'student', ?, 0)
        """, (name, email, phone, department, year, password_hash))
        conn.commit()
        conn.close()

        generate_and_save_otp(email, "signup")
        session["pending_verification_email"] = email
        flash("Account created. Verify your email to continue.", "info")
        return redirect(url_for("verify_otp", purpose="signup"))

    return render_template("signup.html")

@app.route("/verify-otp", methods=["GET", "POST"])
def verify_otp():
    email = session.get("pending_verification_email")
    purpose = session.get("pending_verification_purpose")
    if not email or purpose not in ("signup", "reset_password"):
        return redirect(url_for("login"))
    if request.args.get("purpose", purpose) != purpose:
        abort(400, "Verification purpose does not match this session.")
    if request.method == "POST":
        ok, message = otp_service.verify(email, purpose, request.form.get("otp", "").strip(), app.secret_key)
        if not ok:
            flash(message, "danger")
        elif purpose == "signup":
            with database.get_db_connection() as conn:
                conn.execute("UPDATE users SET email_verified = 1 WHERE email = ?", (email,))
                user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            conn.close()
            session.clear()
            session.update(user_id=user["id"], user_name=user["name"], user_role=user["role"])
            flash("Email verified successfully! Welcome to CampusConnect.", "success")
            return redirect(url_for("home"))
        else:
            session["otp_verified_for_reset"] = email
            session["reset_verified_at"] = time.time()
            session.pop("pending_verification_email", None)
            session.pop("pending_verification_purpose", None)
            return redirect(url_for("reset_password"))
    return render_template("verify_otp.html", email=email, purpose=purpose)

@app.route("/resend-otp", methods=["POST"])
def resend_otp():
    email = session.get("pending_verification_email")
    purpose = session.get("pending_verification_purpose")
    if not email or purpose not in ("signup", "reset_password"):
        return redirect(url_for("login"))
    generate_and_save_otp(email, purpose)
    return redirect(url_for("verify_otp", purpose=purpose))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = database.get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()

        if not user or not check_password_hash(user["password_hash"], password):
            flash("Invalid email or password.", "danger")
            return render_template("login.html")

        if not user["email_verified"]:
            session["pending_verification_email"] = user["email"]
            generate_and_save_otp(user["email"], "signup")
            flash("Please verify your email before logging in.", "warning")
            return redirect(url_for("verify_otp", purpose="signup"))

        session.clear()
        session["user_id"] = user["id"]
        session["user_name"] = user["name"]
        session["user_role"] = user["role"]

        flash(f"Welcome back, {user['name']}!", "success")
        next_url = request.args.get("next")
        if next_url and next_url.startswith("/") and not next_url.startswith("//") and not urlsplit(next_url).netloc and "\\" not in next_url:
            return redirect(next_url)

        if user["role"] in ("organizer", "admin"):
            return redirect(url_for("organizer_dashboard"))
        return redirect(url_for("student_dashboard"))

    return render_template("login.html")

@app.route("/admin")
def admin_redirect():
    return redirect(url_for("login"))

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been signed out safely.", "info")
    return redirect(url_for("home"))

@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        session.pop("otp_verified_for_reset", None)
        session.pop("reset_verified_at", None)
        email = request.form.get("email", "").strip().lower()
        conn = database.get_db_connection()
        user = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()

        if not user:
            flash("If an account exists with this email, a reset OTP has been sent.", "info")
            return render_template("forgot_password.html")

        generate_and_save_otp(email, "reset_password")
        session["pending_verification_email"] = email
        
        return redirect(url_for("verify_otp", purpose="reset_password"))

    return render_template("forgot_password.html")

@app.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    email = session.get("otp_verified_for_reset")
    if not email or time.time() - session.get("reset_verified_at", 0) > 600:
        session.pop("otp_verified_for_reset", None)
        flash("Unauthorized password reset request.", "danger")
        return redirect(url_for("forgot_password"))

    if request.method == "POST":
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template("reset_password.html")

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return render_template("reset_password.html")

        conn = database.get_db_connection()
        conn.execute("UPDATE users SET password_hash = ? WHERE email = ?", (generate_password_hash(password), email))
        conn.commit()
        conn.close()

        session.clear()
        flash("Password updated successfully! Please sign in with your new password.", "success")
        return redirect(url_for("login"))

    return render_template("reset_password.html", email=email)

# ==========================================
# REGISTRATION & DIRECT UPI PAYMENT WORKFLOW
# ==========================================

@app.route("/event/<int:event_id>/register", methods=["POST"])
@login_required
def register_event(event_id):
    user_id = session["user_id"]
    expire_holds()
    conn = database.get_db_connection()
    conn.execute("BEGIN IMMEDIATE")

    # Check if student already registered
    existing = conn.execute("""
        SELECT * FROM registrations WHERE student_id = ? AND event_id = ?
        AND status IN ('Confirmed', 'Pending verification', 'Awaiting payment')
    """, (user_id, event_id)).fetchone()

    if existing:
        conn.close()
        flash(f"You already have an active registration for this event (Booking Ref: {existing['booking_reference']}).", "info")
        if existing["status"] == "Awaiting payment":
            return redirect(url_for("payment_page", booking_ref=existing["booking_reference"]))
        return redirect(url_for("student_dashboard"))

    # Fetch event details with row lock
    event = conn.execute("SELECT * FROM events WHERE id = ? AND is_active = 1", (event_id,)).fetchone()
    if not event:
        conn.close()
        flash("Event not found or inactive.", "danger")
        return redirect(url_for("home"))

    if event["available_seats"] <= 0:
        conn.close()
        flash("Sorry, this event is completely sold out!", "danger")
        return redirect(url_for("event_detail", event_id=event_id))

    # Generate unique booking reference
    booking_ref = f"CC-{datetime.now(timezone.utc).replace(tzinfo=None).strftime('%Y')}-{uuid.uuid4().hex[:8].upper()}"
    server_calculated_amount = float(event["fee"])
    if server_calculated_amount > 0 and database.get_setting("college_upi_id", "") in ("", "campusconnect@upi"):
        conn.close()
        flash("The administrator must configure a real UPI ID before paid registrations open.", "warning")
        return redirect(url_for("event_detail", event_id=event_id))

    # Seat hold duration
    hold_minutes = int(database.get_setting("seat_hold_minutes", "15"))
    seat_hold_expires = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(minutes=hold_minutes)

    cursor = conn.cursor()

    # Free Event: Confirms immediately if seats available
    if server_calculated_amount == 0.0:
        ticket_code = f"TKT-{uuid.uuid4().hex[:10].upper()}"
        cursor.execute("""
            INSERT INTO registrations (
                booking_reference, student_id, event_id, amount, status,
                ticket_code, payment_submitted_at, verified_at
            ) VALUES (?, ?, ?, 0.0, 'Confirmed', ?, datetime('now'), datetime('now'))
        """, (booking_ref, user_id, event_id, ticket_code))

        # Decrement seat
        cursor.execute("UPDATE events SET available_seats = available_seats - 1 WHERE id = ?", (event_id,))
        conn.commit()
        conn.close()

        flash("Registration confirmed successfully! Your free entry ticket is ready.", "success")
        return redirect(url_for("view_ticket", booking_ref=booking_ref))

    # Paid Event: Requires UPI Payment & Manual Verification
    else:
        cursor.execute("""
            INSERT INTO registrations (
                booking_reference, student_id, event_id, amount, status,
                seat_hold_expires_at
            ) VALUES (?, ?, ?, ?, 'Awaiting payment', ?)
        """, (booking_ref, user_id, event_id, server_calculated_amount, seat_hold_expires.strftime("%Y-%m-%d %H:%M:%S")))

        # Temporarily hold the seat
        cursor.execute("UPDATE events SET available_seats = available_seats - 1 WHERE id = ?", (event_id,))
        conn.commit()
        conn.close()

        flash(f"Seat held for {hold_minutes} minutes. Please complete direct UPI payment to proceed.", "info")
        return redirect(url_for("payment_page", booking_ref=booking_ref))

@app.route("/payment/<booking_ref>", methods=["GET", "POST"])
@login_required
def payment_page(booking_ref):
    conn = database.get_db_connection()
    reg = conn.execute("""
        SELECT r.*, e.title as event_title, e.event_date, e.event_time, e.venue, u.name as student_name, u.email as student_email
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        WHERE r.booking_reference = ?
    """, (booking_ref,)).fetchone()

    if not reg:
        conn.close()
        flash("Booking reference not found.", "danger")
        return redirect(url_for("student_dashboard"))

    # Security check: only the student or organizer/admin can view this payment page
    user = get_current_user()
    if not can_access_registration(reg, user):
        conn.close()
        flash("Unauthorized access to payment page.", "danger")
        return redirect(url_for("home"))

    conn.close()
    expire_holds()
    conn = database.get_db_connection()
    conn.execute("BEGIN IMMEDIATE")
    reg = conn.execute("SELECT r.*, e.title as event_title FROM registrations r JOIN events e ON r.event_id=e.id WHERE r.booking_reference=?", (booking_ref,)).fetchone()
    is_expired = reg["status"] == "Expired"

    college_upi_id = database.get_setting("college_upi_id", "campusconnect@upi")
    payee_name = database.get_setting("payee_name", "CampusConnect Events College Fund")
    payment_instructions = database.get_setting("payment_instructions", "")

    if not college_upi_id or college_upi_id == "campusconnect@upi":
        conn.close()
        flash("Payments are unavailable until the administrator sets a real UPI ID in Settings.", "warning")
        return redirect(url_for("student_dashboard"))

    # Handle Payment Submission (UTR & Screenshot Upload)
    if request.method == "POST":
        if reg["status"] not in ("Awaiting payment", "Rejected", "Expired"):
            flash(f"Payment is already in '{reg['status']}' state.", "warning")
            conn.close()
            return redirect(url_for("student_dashboard"))

        upi_ref = request.form.get("upi_reference", "").strip().upper()
        if not re.fullmatch(r"[A-Z0-9]{6,40}", upi_ref):
            flash("Please enter a valid UPI transaction reference / UTR (at least 6 alphanumeric characters).", "danger")
            conn.close()
            return render_template("payment.html", reg=reg, upi_id=college_upi_id, payee_name=payee_name, instructions=payment_instructions)

        # Validate actual contents, not just the file suffix.
        # Handle Receipt Screenshot Upload
        receipt_filename = reg["receipt_filename"]
        file = request.files.get("receipt_file")
        if file and file.filename:
            if not allowed_file(file.filename):
                flash("Invalid file type. Allowed formats: PNG, JPG, JPEG, WEBP, PDF.", "danger")
                conn.close()
                return render_template("payment.html", reg=reg, upi_id=college_upi_id, payee_name=payee_name, instructions=payment_instructions)

            ext = file.filename.rsplit(".", 1)[1].lower()
            try:
                if ext == "pdf":
                    if file.stream.read(5) != b"%PDF-":
                        raise ValueError()
                else:
                    from PIL import Image
                    image = Image.open(file.stream)
                    if image.format not in ("PNG", "JPEG", "WEBP"):
                        raise ValueError()
                    image.verify()
                file.stream.seek(0)
            except Exception:
                conn.close()
                flash("Receipt contents are not a valid image or PDF.", "danger")
                return redirect(url_for("payment_page", booking_ref=booking_ref))
            safe_name = f"receipt_{reg['booking_reference']}_{uuid.uuid4().hex}.{ext}"
            file.save(UPLOAD_DIR / safe_name)
            receipt_filename = safe_name

        if reg["status"] in ("Rejected", "Expired"):
            changed = conn.execute("UPDATE events SET available_seats=available_seats-1 WHERE id=? AND available_seats>0", (reg["event_id"],)).rowcount
            next_status = "Pending verification" if changed else "Refund pending"
        else:
            next_status = "Pending verification"
        # Update submission state
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE registrations
            SET upi_reference = ?, receipt_filename = ?, status = ?,
                payment_submitted_at = datetime('now'), rejection_reason = NULL
            WHERE id = ?
        """, (upi_ref, receipt_filename, next_status, reg["id"]))

        # Add to audit log
        cursor.execute("""
            INSERT INTO audit_logs (registration_id, reviewer_id, action, notes)
            VALUES (?, ?, 'SUBMIT_PAYMENT', ?)
        """, (reg["id"], user["id"], f"Student submitted UTR: {upi_ref}"))

        conn.commit()
        conn.close()

        flash("Your payment details have been submitted! Your registration will be confirmed after the organizer verifies your payment.", "success")
        return redirect(url_for("student_dashboard"))

    conn.close()
    return render_template("payment.html", reg=reg, upi_id=college_upi_id, payee_name=payee_name, instructions=payment_instructions, is_expired=is_expired)

@app.route("/api/upi-qr/<booking_ref>")
@login_required
def generate_upi_qr(booking_ref):
    conn = database.get_db_connection()
    reg = conn.execute("SELECT r.amount, r.student_id, e.organizer_id FROM registrations r JOIN events e ON e.id=r.event_id WHERE booking_reference = ?", (booking_ref,)).fetchone()
    conn.close()

    if not reg:
        abort(404)

    college_upi_id = database.get_setting("college_upi_id", "campusconnect@upi")
    payee_name = database.get_setting("payee_name", "CampusConnect Events College Fund")
    import urllib.parse
    encoded_payee = urllib.parse.quote(payee_name)
    if reg["student_id"] != session["user_id"] and get_current_user()["role"] != "admin" and not (get_current_user()["role"] == "organizer" and reg["organizer_id"] == session["user_id"]):
        abort(403)
    amount_str = f"{reg['amount']:.2f}"

    # UPI URI payload
    upi_payload = "upi://pay?" + urlencode(dict(pa=college_upi_id, pn=payee_name, am=amount_str, cu="INR", tn=booking_ref))

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=3,
    )
    qr.add_data(upi_payload)
    qr.make(fit=True)

    img = qr.make_image(fill_color="#1e293b", back_color="#ffffff")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")

@app.route("/api/ticket-qr/<ticket_code>")
@login_required
def generate_ticket_qr(ticket_code):
    conn = database.get_db_connection()
    reg = conn.execute("""
        SELECT r.ticket_code, r.booking_reference, e.title, u.name, r.student_id, e.organizer_id, r.status
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        WHERE r.ticket_code = ?
    """, (ticket_code,)).fetchone()
    conn.close()

    if not reg:
        abort(404)

    user = get_current_user()
    if reg["status"] != "Confirmed" or not (user["id"] == reg["student_id"] or user["role"] == "admin" or (user["role"] == "organizer" and user["id"] == reg["organizer_id"])):
        abort(403)
    ticket_payload = f"CAMPUSCONNECT-TICKET|{reg['ticket_code']}|{reg['booking_reference']}|{reg['title']}|{reg['name']}"
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_Q,
        box_size=8,
        border=2,
    )
    qr.add_data(ticket_payload)
    qr.make(fit=True)

    img = qr.make_image(fill_color="#0f172a", back_color="#ffffff")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")

@app.route("/receipt/<filename>")
@login_required
def view_receipt(filename):
    user = get_current_user()
    safe_name = secure_filename(filename)
    file_path = UPLOAD_DIR / safe_name

    if not file_path.exists():
        abort(404)

    conn = database.get_db_connection()
    reg = conn.execute("SELECT student_id, event_id FROM registrations WHERE receipt_filename = ?", (safe_name,)).fetchone()
    if not reg:
        conn.close()
        abort(404)

    # Allow student owner or organizer of event or admin
    is_owner = (reg["student_id"] == user["id"])
    is_admin = (user["role"] == "admin")
    is_event_organizer = False
    if user["role"] == "organizer":
        ev = conn.execute("SELECT id FROM events WHERE id = ? AND organizer_id = ?", (reg["event_id"], user["id"])).fetchone()
        if ev:
            is_event_organizer = True
    conn.close()

    if not (is_owner or is_admin or is_event_organizer):
        abort(403)

    return send_file(file_path, as_attachment=True)

# ==========================================
# STUDENT DASHBOARD & TICKETS & REFUNDS
# ==========================================

@app.route("/dashboard")
@login_required
def student_dashboard():
    expire_holds()
    user = get_current_user()
    filter_status = request.args.get("status", "all")

    conn = database.get_db_connection()
    query = """
        SELECT r.*, e.title as event_title, e.event_date, e.event_time, e.venue, e.fee as event_fee
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        WHERE r.student_id = ?
    """
    params = [user["id"]]

    if filter_status != "all":
        query += " AND r.status = ?"
        params.append(filter_status)

    query += " ORDER BY r.id DESC"
    registrations = conn.execute(query, params).fetchall()

    status_counts = {
        "all": conn.execute("SELECT COUNT(*) as count FROM registrations WHERE student_id = ?", (user["id"],)).fetchone()["count"],
        "Awaiting payment": conn.execute("SELECT COUNT(*) as count FROM registrations WHERE student_id = ? AND status = 'Awaiting payment'", (user["id"],)).fetchone()["count"],
        "Pending verification": conn.execute("SELECT COUNT(*) as count FROM registrations WHERE student_id = ? AND status = 'Pending verification'", (user["id"],)).fetchone()["count"],
        "Confirmed": conn.execute("SELECT COUNT(*) as count FROM registrations WHERE student_id = ? AND status = 'Confirmed'", (user["id"],)).fetchone()["count"],
        "Rejected": conn.execute("SELECT COUNT(*) as count FROM registrations WHERE student_id = ? AND status = 'Rejected'", (user["id"],)).fetchone()["count"],
        "Expired": conn.execute("SELECT COUNT(*) as count FROM registrations WHERE student_id = ? AND status = 'Expired'", (user["id"],)).fetchone()["count"],
        "Refund pending": conn.execute("SELECT COUNT(*) as count FROM registrations WHERE student_id = ? AND status = 'Refund pending'", (user["id"],)).fetchone()["count"],
    }
    conn.close()

    return render_template("student_dashboard.html", registrations=registrations, counts=status_counts, current_filter=filter_status)

@app.route("/ticket/<booking_ref>")
@login_required
def view_ticket(booking_ref):
    user = get_current_user()
    conn = database.get_db_connection()
    reg = conn.execute("""
        SELECT r.*, e.title as event_title, e.event_date, e.event_time, e.venue, e.category,
               u.name as student_name, u.email as student_email, u.department as student_dept, u.year as student_year
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        WHERE r.booking_reference = ?
    """, (booking_ref,)).fetchone()
    conn.close()

    if not reg or reg["status"] != "Confirmed":
        flash("Valid entry ticket is available only for Confirmed registrations.", "warning")
        return redirect(url_for("student_dashboard"))

    if not can_access_registration(reg, user):
        abort(403)

    return render_template("ticket.html", reg=reg)

@app.route("/certificate/<booking_ref>")
@login_required
def view_certificate(booking_ref):
    user = get_current_user()
    conn = database.get_db_connection()
    reg = conn.execute("""
        SELECT r.*, e.title as event_title, e.event_date, e.venue, e.category,
               u.name as student_name, u.department as student_dept
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        WHERE r.booking_reference = ?
    """, (booking_ref,)).fetchone()
    conn.close()

    if not reg or reg["status"] != "Confirmed" or reg["attendance_status"] != "Present":
        flash("Participation certificate is issued only after confirmed attendance.", "warning")
        return redirect(url_for("student_dashboard"))

    if not can_access_registration(reg, user):
        abort(403)

    return render_template("certificate.html", reg=reg)

@app.route("/registration/<booking_ref>/request-refund", methods=["POST"])
@login_required
def request_refund(booking_ref):
    user = get_current_user()
    reason = request.form.get("reason", "").strip()

    conn = database.get_db_connection()
    conn.execute("BEGIN IMMEDIATE")
    reg = conn.execute("SELECT * FROM registrations WHERE booking_reference = ? AND student_id = ?", (booking_ref, user["id"])).fetchone()

    if not reg:
        conn.close()
        flash("Registration not found.", "danger")
        return redirect(url_for("student_dashboard"))

    if reg["amount"] == 0:
        flash("This is a free event. No refund is applicable.", "warning")
        conn.close()
        return redirect(url_for("student_dashboard"))

    if reg["status"] not in ("Confirmed", "Pending verification", "Rejected"):
        flash(f"Cannot request refund for registration in '{reg['status']}' state.", "warning")
        conn.close()
        return redirect(url_for("student_dashboard"))

    if reg["status"] in ("Confirmed", "Pending verification"):
        conn.execute("UPDATE events SET available_seats=available_seats+1 WHERE id=?", (reg["event_id"],))

    conn.execute("""
        UPDATE registrations
        SET refund_requested = 1, refund_reason = ?, status = 'Refund pending'
        WHERE id = ?
    """, (reason, reg["id"]))

    conn.execute("""
        INSERT INTO audit_logs (registration_id, reviewer_id, action, notes)
        VALUES (?, ?, 'REFUND_REQUESTED', ?)
    """, (reg["id"], user["id"], f"Student requested refund: {reason}"))

    conn.commit()
    conn.close()

    flash("Refund request submitted to the organizer resolution queue. Refunds are performed manually by college staff.", "info")
    return redirect(url_for("student_dashboard"))

# ==========================================
# ORGANIZER & ADMIN MANAGEMENT DASHBOARD
# ==========================================

@app.route("/organizer/dashboard")
@organizer_required
def organizer_dashboard():
    user = get_current_user()
    conn = database.get_db_connection()

    is_admin = (user["role"] == "admin")
    if is_admin:
        events = conn.execute("SELECT * FROM events ORDER BY id DESC").fetchall()
        event_count = len(events)
        pending_count = conn.execute("SELECT COUNT(*) as count FROM registrations WHERE status = 'Pending verification'").fetchone()["count"]
        confirmed_count = conn.execute("SELECT COUNT(*) as count FROM registrations WHERE status = 'Confirmed'").fetchone()["count"]
        revenue = conn.execute("SELECT SUM(amount) as total FROM registrations WHERE status = 'Confirmed'").fetchone()["total"] or 0.0
        refund_count = conn.execute("SELECT COUNT(*) as count FROM registrations WHERE status = 'Refund pending'").fetchone()["count"]
    else:
        events = conn.execute("SELECT * FROM events WHERE organizer_id = ? ORDER BY id DESC", (user["id"],)).fetchall()
        event_count = len(events)
        event_ids = [e["id"] for e in events]
        if event_ids:
            placeholders = ",".join("?" * len(event_ids))
            pending_count = conn.execute(f"SELECT COUNT(*) as count FROM registrations WHERE status = 'Pending verification' AND event_id IN ({placeholders})", event_ids).fetchone()["count"]
            confirmed_count = conn.execute(f"SELECT COUNT(*) as count FROM registrations WHERE status = 'Confirmed' AND event_id IN ({placeholders})", event_ids).fetchone()["count"]
            revenue = conn.execute(f"SELECT SUM(amount) as total FROM registrations WHERE status = 'Confirmed' AND event_id IN ({placeholders})", event_ids).fetchone()["total"] or 0.0
            refund_count = conn.execute(f"SELECT COUNT(*) as count FROM registrations WHERE status = 'Refund pending' AND event_id IN ({placeholders})", event_ids).fetchone()["count"]
        else:
            pending_count = 0
            confirmed_count = 0
            revenue = 0.0
            refund_count = 0

    conn.close()
    return render_template("organizer_dashboard.html",
                           events=events,
                           event_count=event_count,
                           pending_count=pending_count,
                           confirmed_count=confirmed_count,
                           revenue=revenue,
                           refund_count=refund_count)

@app.route("/organizer/events", methods=["GET", "POST"])
@organizer_required
def organizer_events():
    user = get_current_user()
    conn = database.get_db_connection()

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "Technical").strip()
        description = request.form.get("description", "").strip()
        event_date = request.form.get("event_date", "").strip()
        event_time = request.form.get("event_time", "").strip()
        venue = request.form.get("venue", "").strip()
        try:
            fee = float(request.form.get("fee", 0))
            total_seats = int(request.form.get("total_seats", 50))
            if not (0 <= fee <= 1000000) or not (1 <= total_seats <= 100000):
                raise ValueError()
            datetime.strptime(event_date, "%Y-%m-%d")
        except ValueError:
            conn.close()
            flash("Enter a valid date, nonnegative fee and positive seat count.", "danger")
            return redirect(url_for("organizer_events"))

        if not title or not event_date or not venue:
            flash("Please fill in event title, date, and venue.", "danger")
        else:
            conn.execute("""
                INSERT INTO events (title, category, description, event_date, event_time, venue, fee, total_seats, available_seats, organizer_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (title, category, description, event_date, event_time, venue, fee, total_seats, total_seats, user["id"]))
            conn.commit()
            flash("Event created successfully!", "success")
            conn.close()
            return redirect(url_for("organizer_events"))

    if user["role"] == "admin":
        events = conn.execute("""
            SELECT e.*, u.name as organizer_name
            FROM events e
            JOIN users u ON e.organizer_id = u.id
            ORDER BY e.id DESC
        """).fetchall()
    else:
        events = conn.execute("""
            SELECT e.*, u.name as organizer_name
            FROM events e
            JOIN users u ON e.organizer_id = u.id
            WHERE e.organizer_id = ?
            ORDER BY e.id DESC
        """, (user["id"],)).fetchall()

    conn.close()
    return render_template("organizer_events.html", events=events)

@app.route("/organizer/events/<int:event_id>/delete", methods=["POST"])
@organizer_required
def delete_event(event_id):
    user = get_current_user()
    conn = database.get_db_connection()
    event = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()

    if not event:
        conn.close()
        flash("Event not found.", "danger")
        return redirect(url_for("organizer_events"))

    if user["role"] != "admin" and event["organizer_id"] != user["id"]:
        conn.close()
        flash("Unauthorized to delete this event.", "danger")
        return redirect(url_for("organizer_events"))

    conn.execute("UPDATE events SET is_active=0 WHERE id = ?", (event_id,))
    conn.commit()
    conn.close()
    flash("Event deleted successfully.", "info")
    return redirect(url_for("organizer_events"))

# ==========================================
# ORGANIZER PAYMENT VERIFICATION DASHBOARD
# ==========================================

@app.route("/organizer/payments")
@organizer_required
def organizer_payments():
    user = get_current_user()
    event_filter = request.args.get("event_id", "")
    status_filter = request.args.get("status", "Pending verification")

    conn = database.get_db_connection()

    base_query = """
        SELECT r.*, e.title as event_title, e.available_seats, e.total_seats,
               u.name as student_name, u.email as student_email, u.phone as student_phone,
               rev.name as reviewer_name
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        LEFT JOIN users rev ON r.verified_by = rev.id
        WHERE 1=1
    """
    params = []

    if user["role"] != "admin":
        base_query += " AND e.organizer_id = ?"
        params.append(user["id"])

    if event_filter:
        base_query += " AND r.event_id = ?"
        params.append(event_filter)

    if status_filter != "all":
        base_query += " AND r.status = ?"
        params.append(status_filter)

    base_query += " ORDER BY r.payment_submitted_at DESC, r.id DESC"
    registrations = conn.execute(base_query, params).fetchall()

    # Pre-check duplicate UTRs to flag reuse in UI
    reused_utrs = set()
    rows = conn.execute("""
        SELECT upper(upi_reference) as upi_reference, COUNT(*) as cnt
        FROM registrations
        WHERE upi_reference IS NOT NULL AND upi_reference != '' AND status IN ('Confirmed', 'Pending verification')
        GROUP BY upper(upi_reference)
        HAVING cnt > 1
    """).fetchall()
    for row in rows:
        reused_utrs.add(row["upi_reference"])

    # Load events for filter dropdown
    if user["role"] == "admin":
        my_events = conn.execute("SELECT id, title FROM events ORDER BY title").fetchall()
    else:
        my_events = conn.execute("SELECT id, title FROM events WHERE organizer_id = ? ORDER BY title", (user["id"],)).fetchall()

    conn.close()
    return render_template("organizer_payments.html",
                           registrations=registrations,
                           my_events=my_events,
                           reused_utrs=reused_utrs,
                           current_event=event_filter,
                           current_status=status_filter)

@app.route("/organizer/payments/<int:reg_id>/approve", methods=["POST"])
@organizer_required
def approve_payment(reg_id):
    user = get_current_user()
    conn = database.get_db_connection()

    # Atomic lock
    conn.execute("BEGIN IMMEDIATE")

    reg = conn.execute("""
        SELECT r.*, e.title as event_title, e.organizer_id, e.available_seats, u.email as student_email, u.name as student_name
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        WHERE r.id = ?
    """, (reg_id,)).fetchone()

    if not reg:
        conn.rollback()
        conn.close()
        flash("Registration not found.", "danger")
        return redirect(url_for("organizer_payments"))

    # Isolation check: only event organizer or admin can approve
    if user["role"] != "admin" and reg["organizer_id"] != user["id"]:
        conn.rollback()
        conn.close()
        flash("You are only permitted to verify payments for your own events.", "danger")
        return redirect(url_for("organizer_payments"))

    # Idempotency check: repeated clicks cannot issue duplicate tickets
    if reg["status"] == "Confirmed":
        conn.rollback()
        conn.close()
        flash("This registration is already confirmed and verified.", "info")
        return redirect(url_for("organizer_payments"))

    if reg["status"] != "Pending verification" or not reg["upi_reference"]:
        conn.rollback()
        conn.close()
        flash("Only submitted payments can be approved.", "warning")
        return redirect(url_for("organizer_payments"))

    # UTR Reuse Prevention: Check if this UTR was already verified for ANY OTHER registration
    if reg["upi_reference"]:
        dup = conn.execute("""
            SELECT id, booking_reference FROM registrations
            WHERE upper(upi_reference) = upper(?) AND status = 'Confirmed' AND id != ?
        """, (reg["upi_reference"], reg["id"])).fetchone()

        if dup:
            conn.rollback()
            conn.close()
            flash(f"CRITICAL: Transaction Reference {reg['upi_reference']} was already verified for Booking {dup['booking_reference']}. One payment cannot confirm multiple registrations!", "danger")
            return redirect(url_for("organizer_payments"))

    ticket_code = reg["ticket_code"] or f"TKT-{uuid.uuid4().hex[:10].upper()}"

    # Confirm registration atomically
    conn.execute("""
        UPDATE registrations
        SET status = 'Confirmed', ticket_code = ?, verified_by = ?, verified_at = datetime('now'), rejection_reason = NULL
        WHERE id = ?
    """, (ticket_code, user["id"], reg["id"]))

    # Audit log
    conn.execute("""
        INSERT INTO audit_logs (registration_id, reviewer_id, action, notes)
        VALUES (?, ?, 'APPROVE', ?)
    """, (reg["id"], user["id"], f"Organizer approved payment of ₹{reg['amount']} with UTR {reg['upi_reference']}"))

    conn.commit()
    conn.close()

    # Send confirmation email
    subject = f"Registration Confirmed: {reg['event_title']}"
    body = f"""
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px;">
        <h2 style="color: #16a34a;">Payment Verified & Registration Confirmed!</h2>
        <p>Dear {reg['student_name']},</p>
        <p>Your payment for <strong>{reg['event_title']}</strong> has been verified by the organizer.</p>
        <div style="background: #f8fafc; padding: 15px; border-radius: 6px; margin: 20px 0;">
            <p><strong>Booking Reference:</strong> {reg['booking_reference']}</p>
            <p><strong>Ticket Code:</strong> {ticket_code}</p>
            <p><strong>Amount Paid:</strong> ₹{reg['amount']:.2f}</p>
            <p><strong>Transaction UTR:</strong> {reg['upi_reference']}</p>
        </div>
        <p>You can access your entry QR ticket anytime from your CampusConnect Dashboard.</p>
    </div>
    """
    send_email_notification(reg["student_email"], subject, body)

    flash(f"Payment approved! Ticket {ticket_code} issued for {reg['student_name']}.", "success")
    return redirect(url_for("organizer_payments"))

@app.route("/organizer/payments/<int:reg_id>/reject", methods=["POST"])
@organizer_required
def reject_payment(reg_id):
    user = get_current_user()
    reason = request.form.get("reason", "").strip()
    if not reason:
        reason = "Payment could not be verified in college bank account."

    conn = database.get_db_connection()
    conn.execute("BEGIN IMMEDIATE")

    reg = conn.execute("""
        SELECT r.*, e.organizer_id, e.available_seats, e.id as event_id, u.email as student_email, u.name as student_name, e.title as event_title
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        WHERE r.id = ?
    """, (reg_id,)).fetchone()

    if not reg:
        conn.rollback()
        conn.close()
        flash("Registration not found.", "danger")
        return redirect(url_for("organizer_payments"))

    if user["role"] != "admin" and reg["organizer_id"] != user["id"]:
        conn.rollback()
        conn.close()
        flash("You are only permitted to verify payments for your own events.", "danger")
        return redirect(url_for("organizer_payments"))

    if reg["status"] != "Pending verification":
        conn.rollback()
        conn.close()
        flash("Only pending payments can be rejected.", "warning")
        return redirect(url_for("organizer_payments"))

    # Update to Rejected
    conn.execute("""
        UPDATE registrations
        SET status = 'Rejected', rejection_reason = ?, verified_by = ?, verified_at = datetime('now')
        WHERE id = ?
    """, (reason, user["id"], reg["id"]))

    # Release held seat back to event
    conn.execute("UPDATE events SET available_seats = available_seats + 1 WHERE id = ?", (reg["event_id"],))

    # Audit log
    conn.execute("""
        INSERT INTO audit_logs (registration_id, reviewer_id, action, notes)
        VALUES (?, ?, 'REJECT', ?)
    """, (reg["id"], user["id"], f"Payment rejected. Reason: {reason}"))

    conn.commit()
    conn.close()

    flash(f"Payment rejected for {reg['student_name']}. The student can review the reason and submit a corrected reference from their dashboard.", "warning")
    return redirect(url_for("organizer_payments"))

# ==========================================
# ATTENDANCE & CHECK-IN
# ==========================================

@app.route("/organizer/attendance/<int:event_id>", methods=["GET", "POST"])
@organizer_required
def organizer_attendance(event_id):
    user = get_current_user()
    conn = database.get_db_connection()

    event = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if not event:
        conn.close()
        flash("Event not found.", "danger")
        return redirect(url_for("organizer_dashboard"))

    if user["role"] != "admin" and event["organizer_id"] != user["id"]:
        conn.close()
        flash("Unauthorized to manage attendance for this event.", "danger")
        return redirect(url_for("organizer_dashboard"))

    # Quick check-in via search / QR scan
    if request.method == "POST":
        ticket_input = request.form.get("ticket_code", "").strip()
        if ticket_input.startswith("CAMPUSCONNECT-TICKET|"):
            ticket_input = ticket_input.split("|")[1]
        reg = conn.execute("""
            SELECT r.*, u.name as student_name
            FROM registrations r
            JOIN users u ON r.student_id = u.id
            WHERE r.event_id = ? AND (r.ticket_code = ? OR r.booking_reference = ?) AND r.status = 'Confirmed'
        """, (event_id, ticket_input, ticket_input)).fetchone()

        if not reg:
            flash(f"No confirmed ticket found matching '{ticket_input}'.", "danger")
        else:
            conn.execute("""
                UPDATE registrations
                SET attendance_status = 'Present', attendance_marked_at = datetime('now')
                WHERE id = ?
            """, (reg["id"],))
            conn.commit()
            flash(f"Success! Attendance marked Present for {reg['student_name']} (Ticket: {reg['ticket_code']}).", "success")

    registrations = conn.execute("""
        SELECT r.*, u.name as student_name, u.email as student_email, u.phone as student_phone, u.department
        FROM registrations r
        JOIN users u ON r.student_id = u.id
        WHERE r.event_id = ? AND r.status = 'Confirmed'
        ORDER BY u.name ASC
    """, (event_id,)).fetchall()

    present_count = sum(1 for r in registrations if r["attendance_status"] == "Present")
    total_confirmed = len(registrations)

    conn.close()
    return render_template("organizer_attendance.html",
                           event=event,
                           registrations=registrations,
                           present_count=present_count,
                           total_confirmed=total_confirmed)

@app.route("/organizer/attendance/mark/<int:reg_id>/<status>", methods=["POST"])
@organizer_required
def mark_attendance(reg_id, status):
    if status not in ("Present", "Absent", "Unmarked"):
        flash("Invalid attendance status.", "danger")
        return redirect(url_for("organizer_dashboard"))

    user = get_current_user()
    conn = database.get_db_connection()
    reg = conn.execute("""
        SELECT r.*, e.organizer_id FROM registrations r JOIN events e ON r.event_id = e.id WHERE r.id = ?
    """, (reg_id,)).fetchone()

    if not reg:
        conn.close()
        flash("Registration not found.", "danger")
        return redirect(url_for("organizer_dashboard"))

    if user["role"] != "admin" and reg["organizer_id"] != user["id"]:
        conn.close()
        flash("Unauthorized to update attendance for this event.", "danger")
        return redirect(url_for("organizer_dashboard"))

    conn.execute("""
        UPDATE registrations
        SET attendance_status = ?, attendance_marked_at = datetime('now')
        WHERE id = ?
    """, (status, reg_id))
    conn.commit()
    conn.close()

    flash(f"Attendance status updated to {status}.", "success")
    return redirect(url_for("organizer_dashboard"))

# ==========================================
# RESOLUTION QUEUE & MANUAL REFUNDS
# ==========================================

@app.route("/organizer/refunds")
@organizer_required
def organizer_refunds():
    user = get_current_user()
    conn = database.get_db_connection()

    query = """
        SELECT r.*, e.title as event_title, e.organizer_id,
               u.name as student_name, u.email as student_email, u.phone as student_phone,
               ref_user.name as refunded_by_name
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        LEFT JOIN users ref_user ON r.refunded_by = ref_user.id
        WHERE (r.status IN ('Refund pending', 'Refunded') OR r.refund_requested = 1)
    """
    params = []

    if user["role"] != "admin":
        query += " AND e.organizer_id = ?"
        params.append(user["id"])

    query += " ORDER BY r.id DESC"
    refund_items = conn.execute(query, params).fetchall()
    conn.close()

    return render_template("organizer_refunds.html", refund_items=refund_items)

@app.route("/organizer/refunds/<int:reg_id>/process", methods=["POST"])
@organizer_required
def process_manual_refund(reg_id):
    user = get_current_user()
    refund_ref = request.form.get("refund_reference", "").strip()
    notes = request.form.get("notes", "").strip()

    if not refund_ref:
        flash("Please provide the bank or UPI refund transaction reference (UTR) of the executed payout.", "danger")
        return redirect(url_for("organizer_refunds"))

    conn = database.get_db_connection()
    conn.execute("BEGIN IMMEDIATE")

    reg = conn.execute("""
        SELECT r.*, e.organizer_id, u.email as student_email, u.name as student_name, e.title as event_title
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        JOIN users u ON r.student_id = u.id
        WHERE r.id = ?
    """, (reg_id,)).fetchone()

    if not reg:
        conn.rollback()
        conn.close()
        flash("Registration record not found.", "danger")
        return redirect(url_for("organizer_refunds"))

    if user["role"] != "admin" and reg["organizer_id"] != user["id"]:
        conn.rollback()
        conn.close()
        flash("Unauthorized to process refunds for this event.", "danger")
        return redirect(url_for("organizer_refunds"))

    if reg["status"] != "Refund pending":
        conn.rollback()
        conn.close()
        flash("Only pending refunds can be processed.", "warning")
        return redirect(url_for("organizer_refunds"))

    conn.execute("""
        UPDATE registrations
        SET status = 'Refunded', refund_reference = ?, refunded_at = datetime('now'), refunded_by = ?
        WHERE id = ?
    """, (refund_ref, user["id"], reg["id"]))

    conn.execute("""
        INSERT INTO audit_logs (registration_id, reviewer_id, action, notes)
        VALUES (?, ?, 'REFUND', ?)
    """, (reg["id"], user["id"], f"Staff executed manual refund of ₹{reg['amount']}. Payout UTR: {refund_ref}. Notes: {notes}"))

    conn.commit()
    conn.close()

    # Notify student
    subject = f"Refund Processed: {reg['event_title']}"
    body = f"""
    <div style="font-family: Arial, sans-serif; max-width: 500px; margin: auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px;">
        <h2 style="color: #2563eb;">Manual Refund Executed</h2>
        <p>Dear {reg['student_name']},</p>
        <p>A manual refund of <strong>₹{reg['amount']:.2f}</strong> for <strong>{reg['event_title']}</strong> has been issued to your originating UPI account.</p>
        <p><strong>Bank/UPI Refund Reference:</strong> {refund_ref}</p>
        <p>Please check your bank/UPI statement.</p>
    </div>
    """
    send_email_notification(reg["student_email"], subject, body)

    flash(f"Manual refund recorded successfully! Payout UTR: {refund_ref}.", "success")
    return redirect(url_for("organizer_refunds"))

# ==========================================
# ADMIN SETTINGS & AUDIT LOGS
# ==========================================

@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def admin_settings():
    if request.method == "POST":
        college_upi_id = request.form.get("college_upi_id", "").strip()
        payee_name = request.form.get("payee_name", "").strip()
        seat_hold_minutes = request.form.get("seat_hold_minutes", "15").strip()
        support_email = request.form.get("support_email", "").strip()
        support_phone = request.form.get("support_phone", "").strip()
        payment_instructions = request.form.get("payment_instructions", "").strip()

        if not re.fullmatch(r"[A-Za-z0-9.\-_]{2,256}@[A-Za-z][A-Za-z0-9]{1,63}", college_upi_id) or not payee_name or not seat_hold_minutes.isdigit() or not 1 <= int(seat_hold_minutes) <= 120:
            flash("Enter a valid UPI ID, payee name and hold time (1–120 minutes).", "danger")
            return redirect(url_for("admin_settings"))
        database.set_setting("college_upi_id", college_upi_id)
        database.set_setting("payee_name", payee_name)
        database.set_setting("seat_hold_minutes", seat_hold_minutes)
        database.set_setting("support_email", support_email)
        database.set_setting("support_phone", support_phone)
        database.set_setting("payment_instructions", payment_instructions)

        flash("Admin payment configuration and college settings saved securely.", "success")
        return redirect(url_for("admin_settings"))

    settings = {
        "college_upi_id": database.get_setting("college_upi_id", ""),
        "payee_name": database.get_setting("payee_name", ""),
        "seat_hold_minutes": database.get_setting("seat_hold_minutes", "15"),
        "support_email": database.get_setting("support_email", ""),
        "support_phone": database.get_setting("support_phone", ""),
        "payment_instructions": database.get_setting("payment_instructions", ""),
    }
    return render_template("admin_settings.html", settings=settings)

@app.route("/admin/audit-logs")
@admin_required
def admin_audit_logs():
    conn = database.get_db_connection()
    logs = conn.execute("""
        SELECT a.*, r.booking_reference, u.name as reviewer_name, u.email as reviewer_email, e.title as event_title
        FROM audit_logs a
        JOIN registrations r ON a.registration_id = r.id
        JOIN users u ON a.reviewer_id = u.id
        JOIN events e ON r.event_id = e.id
        ORDER BY a.id DESC
        LIMIT 200
    """).fetchall()
    conn.close()
    return render_template("audit_logs.html", logs=logs)

# ==========================================
# MAIN EXECUTION
# ==========================================

database.init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5001))
    print(f"Starting CampusConnect on http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
