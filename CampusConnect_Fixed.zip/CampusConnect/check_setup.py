"""Check local configuration. Optional self-test email: python check_setup.py --send-test."""
import argparse
import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(__file__).resolve().parent / '.env')
import database
from otp_service import send_email


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--send-test', action='store_true', help='Send a configuration test to the configured sender address')
    args = parser.parse_args()
    database.init_db()
    upi = database.get_setting('college_upi_id')
    checks = {
        'Sender email configured': bool(os.getenv('OTP_EMAIL')),
        'App password configured': bool(os.getenv('OTP_APP_PASSWORD')),
        'Real UPI ID configured': bool(upi and upi != 'campusconnect@upi'),
        'Templates available': (Path(__file__).parent / 'templates' / 'verify_otp.html').exists(),
        'SMTP security configured': os.getenv('SMTP_SECURITY', 'ssl') in ('ssl','starttls'),
    }
    for label, passed in checks.items():
        print(f"{'OK' if passed else 'MISSING'}: {label}")
    if args.send_test:
        if not all(checks.values()):
            raise SystemExit('Complete python setup_config.py first.')
        ok = send_email(os.environ['OTP_EMAIL'], 'CampusConnect email test', '<h2>Email setup works</h2><p>CampusConnect successfully submitted this test message through SMTP.</p>')
        print('SMTP accepted the message. Check your inbox/spam folder.' if ok else 'Delivery failed. Check app password, SMTP settings and network access.')
        if not ok:
            raise SystemExit(1)
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
