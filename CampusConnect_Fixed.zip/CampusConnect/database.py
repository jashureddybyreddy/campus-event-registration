import sqlite3
import os
from pathlib import Path
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "campus_events.db"
UPLOAD_DIR = BASE_DIR / "uploads" / "receipts"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=20.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            phone TEXT NOT NULL,
            department TEXT,
            year TEXT,
            role TEXT NOT NULL DEFAULT 'student', -- 'student', 'organizer', 'admin'
            password_hash TEXT NOT NULL,
            email_verified INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS otp_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            code TEXT NOT NULL,
            purpose TEXT NOT NULL, -- 'signup', 'reset_password'
            expires_at TIMESTAMP NOT NULL,
            is_used INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS system_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            setting_key TEXT UNIQUE NOT NULL,
            setting_value TEXT NOT NULL,
            description TEXT
        );

        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT 'Technical',
            description TEXT,
            event_date TEXT NOT NULL,
            event_time TEXT NOT NULL,
            venue TEXT NOT NULL,
            fee REAL NOT NULL DEFAULT 0,
            total_seats INTEGER NOT NULL,
            available_seats INTEGER NOT NULL,
            organizer_id INTEGER NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (organizer_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_reference TEXT UNIQUE NOT NULL,
            student_id INTEGER NOT NULL,
            event_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'Awaiting payment',
            -- Statuses: 'Awaiting payment', 'Pending verification', 'Confirmed', 'Rejected', 'Expired', 'Refund pending', 'Refunded'
            seat_hold_expires_at TIMESTAMP,
            upi_reference TEXT,
            receipt_filename TEXT,
            payment_submitted_at TIMESTAMP,
            verified_by INTEGER,
            verified_at TIMESTAMP,
            rejection_reason TEXT,
            ticket_code TEXT UNIQUE,
            attendance_status TEXT NOT NULL DEFAULT 'Unmarked', -- 'Unmarked', 'Present', 'Absent'
            attendance_marked_at TIMESTAMP,
            refund_requested INTEGER NOT NULL DEFAULT 0,
            refund_reason TEXT,
            refund_reference TEXT,
            refunded_at TIMESTAMP,
            refunded_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
            FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
            FOREIGN KEY (refunded_by) REFERENCES users(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            registration_id INTEGER NOT NULL,
            reviewer_id INTEGER NOT NULL,
            action TEXT NOT NULL, -- 'SUBMIT_PAYMENT', 'APPROVE', 'REJECT', 'REFUND', 'RESUBMIT', 'SEAT_HOLD_EXPIRED'
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (registration_id) REFERENCES registrations(id) ON DELETE CASCADE,
            FOREIGN KEY (reviewer_id) REFERENCES users(id) ON DELETE CASCADE
        );
    """)

    columns = {row["name"] for row in conn.execute("PRAGMA table_info(otp_codes)")}
    if "attempts" not in columns:
        conn.execute("ALTER TABLE otp_codes ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0")
    conn.execute("DELETE FROM otp_codes WHERE length(code) != 64")
    conn.commit()

    # Seed Default System Settings
    default_settings = [
        ("college_upi_id", "campusconnect@upi", "College direct UPI Virtual Payment Address"),
        ("payee_name", "CampusConnect Events College Fund", "Official Payee Name for UPI transactions"),
        ("seat_hold_minutes", "15", "Duration (in minutes) a seat is held while awaiting payment verification submission"),
        ("support_email", "payments@campusconnect.edu", "Payment resolution and support email address"),
        ("support_phone", "+91 98765 43210", "Payment resolution helpdesk phone number"),
        ("payment_instructions", "1. Open any UPI application (GPay, PhonePe, Paytm, BHIM, etc.).\n2. Scan the QR code or pay to the College UPI ID.\n3. Ensure the amount matches exactly.\n4. Mention your Booking Reference in the transfer note.\n5. Copy the 12-digit UTR/UPI Transaction Reference and take a screenshot of the completed payment.\n6. Submit the reference and screenshot below for organizer verification.", "Payment guidance displayed to students")
    ]

    for key, val, desc in default_settings:
        cursor.execute("""
            INSERT OR IGNORE INTO system_settings (setting_key, setting_value, description)
            VALUES (?, ?, ?)
        """, (key, val, desc))

    # Seed Admin User
    admin_email = "admin@campusconnect.edu"
    cursor.execute("SELECT id FROM users WHERE email = ?", (admin_email,))
    if not cursor.fetchone():
        cursor.execute("""
            INSERT INTO users (name, email, phone, department, year, role, password_hash, email_verified)
            VALUES (?, ?, ?, ?, ?, 'admin', ?, 1)
        """, (
            "Campus Administrator",
            admin_email,
            "9876543200",
            "Central Administration",
            "Staff",
            generate_password_hash("Admin@123")
        ))

    # Seed Sample Organizer
    organizer_email = "organizer@campusconnect.edu"
    cursor.execute("SELECT id FROM users WHERE email = ?", (organizer_email,))
    if not cursor.fetchone():
        cursor.execute("""
            INSERT INTO users (name, email, phone, department, year, role, password_hash, email_verified)
            VALUES (?, ?, ?, ?, ?, 'organizer', ?, 1)
        """, (
            "Prof. Rajesh Sharma",
            organizer_email,
            "9876543201",
            "Computer Science & Engg",
            "Faculty",
            generate_password_hash("Organizer@123")
        ))

    # Seed Sample Student
    student_email = "student@campusconnect.edu"
    cursor.execute("SELECT id FROM users WHERE email = ?", (student_email,))
    if not cursor.fetchone():
        cursor.execute("""
            INSERT INTO users (name, email, phone, department, year, role, password_hash, email_verified)
            VALUES (?, ?, ?, ?, ?, 'student', ?, 1)
        """, (
            "Aarav Patel",
            student_email,
            "9876543202",
            "Information Technology",
            "3rd Year",
            generate_password_hash("Student@123")
        ))

    conn.commit()

    # Seed Sample Events if empty
    cursor.execute("SELECT COUNT(*) as count FROM events")
    if cursor.fetchone()["count"] == 0:
        cursor.execute("SELECT id FROM users WHERE role = 'organizer' LIMIT 1")
        org_row = cursor.fetchone()
        org_id = org_row["id"] if org_row else 1

        sample_events = [
            (
                "National Web3 & AI Hackathon 2026",
                "Technical",
                "A 24-hour national level coding hackathon featuring AI track, Web3 applications, and IoT prototyping. Free registration for all verified campus students.",
                "2026-11-15",
                "09:00 AM",
                "Main Auditorium & CS Labs",
                0.0,
                120,
                116,
                org_id
            ),
            (
                "Cloud Computing & DevOps Masterclass",
                "Workshop",
                "Hands-on workshop covering Docker, Kubernetes, CI/CD pipelines, and cloud deployment architecture. Includes physical laboratory access and completion certificate.",
                "2026-11-20",
                "10:00 AM",
                "Lab 402, Technology Block",
                250.0,
                60,
                58,
                org_id
            ),
            (
                "Campus Cultural Gala: Pro-Show Pass",
                "Cultural",
                "Live band performance, dance showcase, food stalls, and celebrity artist concert pass. Valid for campus students and registered guests.",
                "2026-11-28",
                "05:30 PM",
                "Campus Open Air Amphitheatre",
                150.0,
                300,
                295,
                org_id
            )
        ]

        cursor.executemany("""
            INSERT INTO events (title, category, description, event_date, event_time, venue, fee, total_seats, available_seats, organizer_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, sample_events)
        conn.commit()

    conn.close()

def get_setting(key, default=""):
    conn = get_db_connection()
    row = conn.execute("SELECT setting_value FROM system_settings WHERE setting_key = ?", (key,)).fetchone()
    conn.close()
    return row["setting_value"] if row else default

def set_setting(key, value, description=""):
    conn = get_db_connection()
    conn.execute("""
        INSERT INTO system_settings (setting_key, setting_value, description)
        VALUES (?, ?, ?)
        ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value
    """, (key, str(value), description))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at:", DB_PATH)
