"""Portable source packager. Never includes .env, session secrets or uploaded receipts."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

BASE = Path(__file__).resolve().parent
OUTPUT = BASE.parent / 'CampusConnect_Fixed.zip'
FILES = ['app.py','database.py','otp_service.py','setup_config.py','check_setup.py',
         'make_zip.py','requirements.txt','README.md','TEST_REPORT.md',
         'test_app.py','test_original.py','campus_events.db','.env.example','.gitignore']


def main():
    with ZipFile(OUTPUT, 'w', ZIP_DEFLATED) as archive:
        for name in FILES:
            file = BASE / name
            if file.is_file():
                archive.write(file, 'CampusConnect/' + name)
        for file in sorted((BASE / 'templates').glob('*.html')):
            archive.write(file, 'CampusConnect/templates/' + file.name)
    print(OUTPUT)


if __name__ == '__main__':
    main()
