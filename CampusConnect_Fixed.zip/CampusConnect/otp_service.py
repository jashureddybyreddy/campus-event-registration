"""Real SMTP delivery and single-use, purpose-bound verification codes."""
import hashlib
import hmac
import os
import secrets
import smtplib
import ssl
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
import database


def send_email(recipient, subject, html):
    sender = os.getenv('OTP_EMAIL', '').strip()
    password = os.getenv('OTP_APP_PASSWORD', '').replace(' ', '')
    if not sender or not password:
        return False
    try:
        msg = EmailMessage()
        msg['From'] = sender
        msg['To'] = recipient
        msg['Subject'] = subject
        msg.set_content('Open this email in an HTML-capable email client to view your CampusConnect notification.')
        msg.add_alternative(html, subtype='html')
        host = os.getenv('SMTP_HOST', 'smtp.gmail.com')
        port = int(os.getenv('SMTP_PORT', '465'))
        mode = os.getenv('SMTP_SECURITY', 'ssl').lower()
        if mode not in ('ssl', 'starttls'):
            return False
        smtp_class = smtplib.SMTP_SSL if mode == 'ssl' else smtplib.SMTP
        kwargs = {'timeout': 20}
        if mode == 'ssl':
            kwargs['context'] = ssl.create_default_context()
        with smtp_class(host, port, **kwargs) as server:
            if mode == 'starttls':
                server.ehlo()
                server.starttls(context=ssl.create_default_context())
                server.ehlo()
            server.login(sender, password)
            return not bool(server.send_message(msg))
    except (OSError, smtplib.SMTPException, ValueError):
        # Do not print credentials, message contents or codes.
        return False


def digest(email, purpose, code, secret):
    return hmac.new(str(secret).encode(), f'{email}|{purpose}|{code}'.encode(), hashlib.sha256).hexdigest()


def issue(email, purpose, secret):
    if purpose not in ('signup', 'reset_password'):
        return False, 'Invalid verification purpose.'
    conn = database.get_db_connection()
    try:
        conn.execute('BEGIN IMMEDIATE')
        recent = conn.execute("SELECT created_at FROM otp_codes WHERE email=? AND purpose=? ORDER BY id DESC LIMIT 1", (email, purpose)).fetchone()
        if recent and (datetime.now(timezone.utc).replace(tzinfo=None) - datetime.strptime(recent['created_at'], '%Y-%m-%d %H:%M:%S')).total_seconds() < 60:
            return False, 'Please wait 60 seconds before requesting another code. Check your inbox and spam folder.'
        count = conn.execute("SELECT COUNT(*) FROM otp_codes WHERE email=? AND created_at > datetime('now', '-1 hour')", (email,)).fetchone()[0]
        if count >= 10:
            return False, 'Too many requests. Please try again in an hour.'
        code = f'{secrets.randbelow(1000000):06d}'
        if not send_email(email, 'Your CampusConnect verification code', f'<h2>CampusConnect verification</h2><p>Your code is <strong>{code}</strong>.</p><p>It expires in 10 minutes. Use it only on CampusConnect.</p>'):
            return False, 'Email could not be sent. Ask the administrator to check OTP_EMAIL, OTP_APP_PASSWORD and SMTP settings, then resend.'
        conn.execute('UPDATE otp_codes SET is_used=1 WHERE email=? AND purpose=? AND is_used=0', (email, purpose))
        conn.execute('INSERT INTO otp_codes(email, code, purpose, expires_at) VALUES(?,?,?,?)', (email, digest(email, purpose, code, secret), purpose, (datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(minutes=10)).strftime('%Y-%m-%d %H:%M:%S')))
        conn.commit()
        return True, 'A verification code was sent to your email. Check your inbox and spam folder.'
    finally:
        conn.rollback()
        conn.close()


def verify(email, purpose, code, secret):
    conn = database.get_db_connection()
    try:
        conn.execute('BEGIN IMMEDIATE')
        row = conn.execute("SELECT * FROM otp_codes WHERE email=? AND purpose=? AND is_used=0 ORDER BY id DESC LIMIT 1", (email, purpose)).fetchone()
        if not row or row['expires_at'] <= datetime.now(timezone.utc).replace(tzinfo=None).strftime('%Y-%m-%d %H:%M:%S'):
            return False, 'Invalid or expired code. Request a new code.'
        if row['attempts'] >= 5:
            return False, 'Too many incorrect attempts. Request a new code.'
        if len(code) != 6 or not code.isascii() or not code.isdigit() or not hmac.compare_digest(row['code'], digest(email, purpose, code, secret)):
            conn.execute('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?', (row['id'],))
            conn.commit()
            return False, 'Incorrect code. Five attempts are allowed per code.'
        conn.execute('UPDATE otp_codes SET is_used=1 WHERE id=?', (row['id'],))
        conn.commit()
        return True, 'Verified.'
    finally:
        conn.rollback()
        conn.close()
