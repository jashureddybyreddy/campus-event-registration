"""Run locally: credentials are entered privately, never in chat."""
from getpass import getpass
from pathlib import Path
import os
import re
import secrets
from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent

def main():
    load_dotenv(BASE / '.env')
    print('CampusConnect setup — keep .env private.')
    email = input('Sender Gmail address: ').strip()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
        raise SystemExit('Enter a valid email address.')
    password = getpass('Email app password (hidden): ').replace(' ', '')
    upi = input('Your UPI ID (example: name@bank): ').strip()
    name = input('UPI payee name: ').strip()
    if not password or not re.fullmatch(r'[A-Za-z0-9.\-_]{2,256}@[A-Za-z][A-Za-z0-9]{1,63}', upi) or not name:
        raise SystemExit('App password, valid UPI ID and payee name are required.')
    if any(c in email + password for c in '\n\r\''):
        raise SystemExit('Invalid configuration characters.')
    secret = os.getenv('FLASK_SECRET_KEY')
    if not secret:
        secret_path = BASE / '.session_secret'
        secret = secret_path.read_text().strip() if secret_path.exists() else secrets.token_hex(32)
    env = BASE / '.env'
    env.write_text(f"OTP_EMAIL='{email}'\nOTP_APP_PASSWORD='{password}'\nSMTP_HOST=smtp.gmail.com\nSMTP_PORT=465\nSMTP_SECURITY=ssl\nFLASK_SECRET_KEY='{secret}'\nFLASK_DEBUG=false\nCOOKIE_SECURE=false\n")
    try:
        env.chmod(0o600)
    except OSError:
        pass
    import database
    database.init_db()
    database.set_setting('college_upi_id', upi)
    database.set_setting('payee_name', name)
    print('Saved. Run python app.py. You can change UPI details in Admin > Settings.')

if __name__ == '__main__':
    main()
