import io
import os
import re
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
import app as module
from app import app
import database
import otp_service


class RegressionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = database.DB_PATH
        self.upload = module.UPLOAD_DIR
        database.DB_PATH = Path(self.temp.name) / 'test.db'
        module.UPLOAD_DIR = Path(self.temp.name)
        database.init_db()
        database.set_setting('college_upi_id', 'jaswanth@testbank')
        app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)
        self.client = app.test_client()
        self.sender = patch('otp_service.send_email', return_value=True)
        self.mail = self.sender.start()

    def tearDown(self):
        self.sender.stop()
        database.DB_PATH = self.db
        module.UPLOAD_DIR = self.upload
        self.temp.cleanup()
        app.config['WTF_CSRF_ENABLED'] = True

    def login(self, role='student'):
        return self.client.post('/login', data={'email':f'{role}@campusconnect.edu', 'password':role.title()+'@123'})

    def row(self, query, args=()):
        conn = database.get_db_connection()
        result = conn.execute(query, args).fetchone()
        conn.close()
        return result

    def sql(self, query, args=()):
        conn = database.get_db_connection()
        conn.execute(query, args)
        conn.commit()
        conn.close()

    def issue(self, purpose='signup'):
        self.assertTrue(otp_service.issue('new@example.com', purpose, app.secret_key)[0])
        return re.search(r'<strong>(\d{6})</strong>', self.mail.call_args.args[2]).group(1)

    def test_otp_hash_single_use_and_purpose(self):
        code = self.issue()
        stored = self.row('SELECT * FROM otp_codes')['code']
        self.assertNotEqual(stored, code)
        self.assertEqual(len(stored), 64)
        self.assertFalse(otp_service.verify('new@example.com','reset_password',code,app.secret_key)[0])
        self.assertTrue(otp_service.verify('new@example.com','signup',code,app.secret_key)[0])
        self.assertFalse(otp_service.verify('new@example.com','signup',code,app.secret_key)[0])

    def test_expiry_and_attempt_limit(self):
        code = self.issue()
        for _ in range(5):
            self.assertFalse(otp_service.verify('new@example.com','signup','x',app.secret_key)[0])
        self.assertFalse(otp_service.verify('new@example.com','signup',code,app.secret_key)[0])
        self.sql("UPDATE otp_codes SET attempts=0,expires_at=datetime('now','-1 minute')")
        self.assertFalse(otp_service.verify('new@example.com','signup',code,app.secret_key)[0])

    def test_resend_cooldown_invalidates_previous(self):
        old = self.issue()
        self.assertFalse(otp_service.issue('new@example.com','signup',app.secret_key)[0])
        self.assertEqual(self.mail.call_count, 1)
        self.sql("UPDATE otp_codes SET created_at=datetime('now','-2 minutes')")
        with patch('otp_service.secrets.randbelow', return_value=(int(old)+1)%1000000):
            new = self.issue()
        self.assertFalse(otp_service.verify('new@example.com','signup',old,app.secret_key)[0])
        self.assertTrue(otp_service.verify('new@example.com','signup',new,app.secret_key)[0])

    def test_delivery_failure_keeps_previous_code(self):
        code = self.issue()
        self.sql("UPDATE otp_codes SET created_at=datetime('now','-2 minutes')")
        self.mail.return_value = False
        self.assertFalse(otp_service.issue('new@example.com','signup',app.secret_key)[0])
        self.assertEqual(self.row('SELECT COUNT(*) n FROM otp_codes')['n'], 1)
        self.assertTrue(otp_service.verify('new@example.com','signup',code,app.secret_key)[0])

    def test_signup_verifies_email_without_browser_code(self):
        response = self.client.post('/signup', data=dict(name='New Student',email='new@example.com',phone='9876543210',password='Password123',confirm_password='Password123'), follow_redirects=True)
        self.assertEqual(response.status_code,200)
        code = re.search(r'<strong>(\d{6})</strong>', self.mail.call_args.args[2]).group(1)
        self.assertNotIn(code.encode(), response.data)
        self.assertNotIn(b'Demo Code', response.data)
        self.assertEqual(self.client.post('/verify-otp?purpose=reset_password', data={'otp':code}).status_code,400)
        response = self.client.post('/verify-otp',data={'otp':code},follow_redirects=True)
        self.assertIn(b'Email verified successfully',response.data)
        self.assertEqual(self.row("SELECT email_verified FROM users WHERE email='new@example.com'")[0],1)

    def test_password_reset_end_to_end(self):
        self.client.post('/forgot-password',data={'email':'student@campusconnect.edu'})
        code = re.search(r'<strong>(\d{6})</strong>', self.mail.call_args.args[2]).group(1)
        self.client.post('/verify-otp?purpose=reset_password',data={'otp':code})
        r = self.client.post('/reset-password',data={'password':'Changed123','confirm_password':'Changed123'},follow_redirects=True)
        self.assertIn(b'Password updated successfully',r.data)
        self.assertEqual(self.client.post('/login',data={'email':'student@campusconnect.edu','password':'Changed123'}).status_code,302)
        self.client.post('/logout')
        self.assertEqual(self.client.get('/reset-password').status_code,302)

    def test_reset_authorization_expires(self):
        with self.client.session_transaction() as sess:
            sess['otp_verified_for_reset']='student@campusconnect.edu'
            sess['reset_verified_at']=0
        self.assertEqual(self.client.post('/reset-password',data={'password':'BadChange','confirm_password':'BadChange'}).status_code,302)
        self.assertEqual(self.login().status_code,302)

    def test_real_csrf_forms(self):
        app.config['WTF_CSRF_ENABLED']=True
        self.assertEqual(self.client.post('/login',data={}).status_code,400)
        page = self.client.get('/login')
        token = re.search(rb'name="csrf_token" value="([^"]+)"',page.data).group(1).decode()
        r = self.client.post('/login',data={'email':'student@campusconnect.edu','password':'Student@123','csrf_token':token})
        self.assertEqual(r.status_code,302)
        self.assertEqual(self.client.get('/resend-otp').status_code,405)

    def test_pages_for_each_role(self):
        for path in ['/','/login','/signup','/forgot-password','/event/1','/health']:
            self.assertEqual(self.client.get(path).status_code,200,path)
        for role,paths in [('student',['/dashboard']),('organizer',['/organizer/dashboard','/organizer/events','/organizer/payments','/organizer/refunds','/organizer/attendance/1']),('admin',['/admin/settings','/admin/audit-logs'])]:
            self.login(role)
            for path in paths:
                self.assertEqual(self.client.get(path).status_code,200,path)
            self.client.post('/logout')

    def test_expired_holds_release_once_and_late_submission(self):
        self.login()
        seats=self.row('SELECT available_seats FROM events WHERE id=2')[0]
        self.client.post('/event/2/register')
        reg=self.row('SELECT * FROM registrations')
        self.sql("UPDATE registrations SET seat_hold_expires_at=datetime('now','-1 minute')")
        module.expire_holds(); module.expire_holds()
        self.assertEqual(self.row('SELECT available_seats FROM events WHERE id=2')[0],seats)
        self.client.post('/payment/'+reg['booking_reference'], data={'upi_reference':'ABC123456'})
        self.assertEqual(self.row('SELECT status FROM registrations')[0],'Pending verification')
        self.assertEqual(self.row('SELECT available_seats FROM events WHERE id=2')[0],seats-1)

    def test_expired_payment_without_seats_goes_to_resolution(self):
        self.login()
        self.client.post('/event/2/register')
        reg=self.row('SELECT * FROM registrations')
        self.sql("UPDATE registrations SET seat_hold_expires_at=datetime('now','-1 minute')")
        module.expire_holds()
        self.sql('UPDATE events SET available_seats=0 WHERE id=2')
        self.client.post('/payment/'+reg['booking_reference'],data={'upi_reference':'ABC123456'})
        self.assertEqual(self.row('SELECT status FROM registrations')[0],'Refund pending')

    def test_rejection_idempotent_and_approval_state_guard(self):
        self.login()
        self.client.post('/event/2/register')
        reg=self.row('SELECT * FROM registrations')
        self.client.post('/payment/'+reg['booking_reference'],data={'upi_reference':'ABC123456'})
        self.client.post('/logout'); self.login('organizer')
        path=f"/organizer/payments/{reg['id']}/reject"
        self.client.post(path,data={'reason':'Not received'})
        seats=self.row('SELECT available_seats FROM events WHERE id=2')[0]
        self.client.post(path,data={'reason':'Not received'})
        self.assertEqual(self.row('SELECT available_seats FROM events WHERE id=2')[0],seats)
        self.client.post(f"/organizer/payments/{reg['id']}/approve")
        self.assertEqual(self.row('SELECT status FROM registrations')[0],'Rejected')

    def test_receipt_rejects_disguised_file(self):
        self.login(); self.client.post('/event/2/register')
        reg=self.row('SELECT * FROM registrations')
        self.client.post('/payment/'+reg['booking_reference'],data={'upi_reference':'ABC123456','receipt_file':(io.BytesIO(b'<script>alert(1)</script>'),'fake.png')})
        self.assertEqual(self.row('SELECT status FROM registrations')[0],'Awaiting payment')

    def test_attendance_certificate_and_refund(self):
        self.login(); self.client.post('/event/2/register')
        reg=self.row('SELECT * FROM registrations')
        self.client.post('/payment/'+reg['booking_reference'],data={'upi_reference':'ABC123456'})
        self.client.post('/logout'); self.login('organizer')
        self.client.post(f"/organizer/payments/{reg['id']}/approve")
        ticket=self.row('SELECT ticket_code FROM registrations')[0]
        self.client.post('/organizer/attendance/2',data={'ticket_code':f'CAMPUSCONNECT-TICKET|{ticket}|ignored'})
        self.client.post('/logout'); self.login()
        self.assertEqual(self.client.get('/certificate/'+reg['booking_reference']).status_code,200)
        seats=self.row('SELECT available_seats FROM events WHERE id=2')[0]
        self.client.post('/registration/'+reg['booking_reference']+'/request-refund',data={'reason':'Cannot attend'})
        self.assertEqual(self.row('SELECT available_seats FROM events WHERE id=2')[0],seats+1)
        self.client.post('/logout'); self.login('organizer')
        self.client.post(f"/organizer/refunds/{reg['id']}/process",data={'refund_reference':'REFUND123'})
        self.assertEqual(self.row('SELECT status FROM registrations')[0],'Refunded')
        self.assertEqual(self.client.get('/api/ticket-qr/'+ticket).status_code,403)

    def test_validation_and_upi_settings(self):
        self.login('admin')
        self.client.post('/admin/settings',data={'college_upi_id':'bad&am=1','payee_name':'Test','seat_hold_minutes':'oops'})
        self.assertEqual(database.get_setting('college_upi_id'),'jaswanth@testbank')
        self.assertEqual(self.client.post('/organizer/events',data={'fee':'bad','total_seats':'bad'},follow_redirects=True).status_code,200)

    def test_payment_qr_requires_owner(self):
        self.login(); self.client.post('/event/2/register')
        reg=self.row('SELECT * FROM registrations')
        self.client.post('/logout')
        self.assertEqual(self.client.get('/api/upi-qr/'+reg['booking_reference']).status_code,302)
        self.login('admin')
        self.assertEqual(self.client.get('/api/upi-qr/'+reg['booking_reference']).status_code,200)

    def test_hourly_email_limit(self):
        for i in range(10):
            self.sql("INSERT INTO otp_codes(email,code,purpose,expires_at,created_at) VALUES('new@example.com',?,'signup',datetime('now','+10 minutes'),datetime('now','-2 minutes'))",(str(i),))
        self.assertFalse(otp_service.issue('new@example.com','signup',app.secret_key)[0])
        self.mail.assert_not_called()

    def test_concurrent_reservations_cannot_oversell(self):
        from concurrent.futures import ThreadPoolExecutor
        self.sql("UPDATE events SET available_seats=1,total_seats=1 WHERE id=2")
        self.sql("INSERT INTO users(name,email,phone,role,password_hash,email_verified) VALUES('Other','other@example.com','123','student','unused',1)")
        other=self.row("SELECT id FROM users WHERE email='other@example.com'")[0]
        def reserve(uid):
            client=app.test_client()
            with client.session_transaction() as sess:
                sess['user_id']=uid
            return client.post('/event/2/register').status_code
        with ThreadPoolExecutor(max_workers=2) as pool:
            self.assertEqual(list(pool.map(reserve,[3,other])),[302,302])
        self.assertEqual(self.row('SELECT COUNT(*) FROM registrations')[0],1)
        self.assertEqual(self.row('SELECT available_seats FROM events WHERE id=2')[0],0)

    def test_unrelated_organizer_cannot_view_booking(self):
        self.login(); self.client.post('/event/2/register')
        reg=self.row('SELECT * FROM registrations')
        self.sql("INSERT INTO users(name,email,phone,role,password_hash,email_verified) VALUES('Other organizer','org@example.com','123','organizer','unused',1)")
        uid=self.row("SELECT id FROM users WHERE email='org@example.com'")[0]
        with self.client.session_transaction() as sess:
            sess.clear(); sess['user_id']=uid
        self.assertEqual(self.client.get('/api/upi-qr/'+reg['booking_reference']).status_code,403)
        self.assertEqual(self.client.get('/payment/'+reg['booking_reference']).status_code,302)

    def test_setup_saves_private_credentials_and_upi(self):
        import setup_config
        with patch.object(setup_config,'BASE',Path(self.temp.name)), patch.object(setup_config,'load_dotenv'), patch('builtins.input',side_effect=['sender@gmail.com','myname@testbank','My Payee']), patch.object(setup_config,'getpass',return_value='abcd efgh ijkl mnop'), patch('builtins.print'):
            setup_config.main()
        config=(Path(self.temp.name)/'.env').read_text()
        self.assertIn("OTP_EMAIL='sender@gmail.com'",config)
        self.assertIn("OTP_APP_PASSWORD='abcdefghijklmnop'",config)
        self.assertEqual(database.get_setting('college_upi_id'),'myname@testbank')
        self.assertEqual(database.get_setting('payee_name'),'My Payee')


class SMTPTests(unittest.TestCase):
    def test_missing_credentials_is_failure(self):
        with patch.dict(os.environ, {'OTP_EMAIL':'','OTP_APP_PASSWORD':''}):
            self.assertFalse(otp_service.send_email('target@example.com','Test','test'))

    def test_ssl_delivery_and_app_password_spaces(self):
        with patch.dict(os.environ,{'OTP_EMAIL':'sender@example.com','OTP_APP_PASSWORD':'abcd efgh ijkl mnop','SMTP_SECURITY':'ssl','SMTP_PORT':'465'}), patch('otp_service.smtplib.SMTP_SSL') as smtp:
            server=smtp.return_value.__enter__.return_value
            server.send_message.return_value={}
            self.assertTrue(otp_service.send_email('target@example.com','Test','<p>Test</p>'))
            server.login.assert_called_once_with('sender@example.com','abcdefghijklmnop')

    def test_starttls_delivery(self):
        with patch.dict(os.environ,{'OTP_EMAIL':'sender@example.com','OTP_APP_PASSWORD':'secret','SMTP_SECURITY':'starttls','SMTP_PORT':'587'}), patch('otp_service.smtplib.SMTP') as smtp:
            server=smtp.return_value.__enter__.return_value
            server.send_message.return_value={}
            self.assertTrue(otp_service.send_email('target@example.com','Test','test'))
            server.starttls.assert_called_once()

    def test_smtp_auth_failure(self):
        import smtplib
        with patch.dict(os.environ,{'OTP_EMAIL':'sender@example.com','OTP_APP_PASSWORD':'secret','SMTP_SECURITY':'ssl'}), patch('otp_service.smtplib.SMTP_SSL',side_effect=smtplib.SMTPAuthenticationError(535,b'bad credentials')):
            self.assertFalse(otp_service.send_email('target@example.com','Test','test'))


if __name__ == '__main__':
    unittest.main()
