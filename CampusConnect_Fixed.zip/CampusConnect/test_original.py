import unittest
import io
import tempfile
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from app import app
import database

class CampusConnectDirectUPITestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.original_db = database.DB_PATH
        cls.original_upload = app.config["UPLOAD_FOLDER"]
        import app as module
        cls.module = module
        cls.original_module_upload = module.UPLOAD_DIR
        database.DB_PATH = Path(cls.temp.name) / "test.db"
        module.UPLOAD_DIR = Path(cls.temp.name)
        database.init_db()
        cls.mail = patch("otp_service.send_email", return_value=True)
        cls.mail.start()

    @classmethod
    def tearDownClass(cls):
        cls.mail.stop()
        database.DB_PATH = cls.original_db
        cls.module.UPLOAD_DIR = cls.original_module_upload
        cls.temp.cleanup()

    def setUp(self):
        app.config["TESTING"] = True
        app.config["WTF_CSRF_ENABLED"] = False
        self.client = app.test_client()
        database.init_db()

    def test_01_health_and_no_razorpay(self):
        resp = self.client.get("/health")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["status"], "ok")
        self.assertEqual(data["razorpay_integrated"], False)
        self.assertIn("Direct UPI", data["payment_gateway"])

    def test_02_home_page(self):
        resp = self.client.get("/")
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"Discover Campus Events", resp.data)
        self.assertIn(b"Direct UPI Payments", resp.data)

    def test_03_logins(self):
        # Student login
        resp = self.client.post("/login", data={
            "email": "student@campusconnect.edu",
            "password": "Student@123"
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"My Registrations", resp.data)

        # Logout
        self.client.post("/logout")

        # Admin login
        resp = self.client.post("/login", data={
            "email": "admin@campusconnect.edu",
            "password": "Admin@123"
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"Organizer Hub", resp.data)

    def test_04_admin_settings_upi_config(self):
        # Login as Admin
        self.client.post("/login", data={
            "email": "admin@campusconnect.edu",
            "password": "Admin@123"
        })

        # Update UPI settings
        resp = self.client.post("/admin/settings", data={
            "college_upi_id": "testcollege@sbi",
            "payee_name": "Test Engineering College Fund",
            "seat_hold_minutes": "20",
            "support_email": "help@testcollege.edu",
            "support_phone": "+91 99999 88888",
            "payment_instructions": "Pay exact amount and mention ref in note."
        }, follow_redirects=True)

        self.assertEqual(resp.status_code, 200)
        self.assertEqual(database.get_setting("college_upi_id"), "testcollege@sbi")
        self.assertEqual(database.get_setting("payee_name"), "Test Engineering College Fund")
        self.assertEqual(database.get_setting("seat_hold_minutes"), "20")

    def test_05_free_event_registration(self):
        # Login as Student
        self.client.post("/login", data={
            "email": "student@campusconnect.edu",
            "password": "Student@123"
        })

        # Register for Free Event (id=1)
        resp = self.client.post("/event/1/register", follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"Registration confirmed successfully", resp.data)
        self.assertIn(b"CAMPUSCONNECT OFFICIAL ENTRY PASS", resp.data)

    def test_06_paid_event_workflow_and_verification(self):
        # Login as Student
        self.client.post("/login", data={
            "email": "student@campusconnect.edu",
            "password": "Student@123"
        })

        # Register for Paid Event (id=2, fee=250)
        resp = self.client.post("/event/2/register", follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"DIRECT UPI PAYMENT", resp.data)
        self.assertIn(b"250.00", resp.data)

        # Get Booking Reference from page
        conn = database.get_db_connection()
        reg = conn.execute("SELECT * FROM registrations WHERE student_id = 3 AND event_id = 2 ORDER BY id DESC LIMIT 1").fetchone()
        self.assertIsNotNone(reg)
        booking_ref = reg["booking_reference"]
        reg_id = reg["id"]
        self.assertEqual(reg["status"], "Awaiting payment")
        conn.close()

        # Test UPI QR Code API
        qr_resp = self.client.get(f"/api/upi-qr/{booking_ref}")
        self.assertEqual(qr_resp.status_code, 200)
        self.assertEqual(qr_resp.mimetype, "image/png")

        # Submit Payment (UTR and screenshot)
        image = io.BytesIO()
        Image.new("RGB", (8, 8)).save(image, format="PNG")
        image.seek(0)
        mock_file = (image, "screenshot.png")
        sub_resp = self.client.post(f"/payment/{booking_ref}", data={
            "upi_reference": "UTR987654321012",
            "receipt_file": mock_file
        }, content_type="multipart/form-data", follow_redirects=True)

        self.assertEqual(sub_resp.status_code, 200)
        self.assertIn(b"Your registration will be confirmed after the organizer verifies", sub_resp.data)

        # Check status in DB
        conn = database.get_db_connection()
        reg_updated = conn.execute("SELECT * FROM registrations WHERE id = ?", (reg_id,)).fetchone()
        self.assertEqual(reg_updated["status"], "Pending verification")
        self.assertEqual(reg_updated["upi_reference"], "UTR987654321012")
        conn.close()

        # Switch to Organizer
        self.client.post("/logout")
        self.client.post("/login", data={
            "email": "organizer@campusconnect.edu",
            "password": "Organizer@123"
        })

        # Organizer Views Payments Dashboard
        dash_resp = self.client.get("/organizer/payments")
        self.assertEqual(dash_resp.status_code, 200)
        self.assertIn(b"UTR987654321012", dash_resp.data)

        # Organizer Approves Payment
        appr_resp = self.client.post(f"/organizer/payments/{reg_id}/approve", follow_redirects=True)
        self.assertEqual(appr_resp.status_code, 200)
        self.assertIn(b"Payment approved", appr_resp.data)

        # Verify status became Confirmed and ticket code issued
        conn = database.get_db_connection()
        reg_conf = conn.execute("SELECT * FROM registrations WHERE id = ?", (reg_id,)).fetchone()
        self.assertEqual(reg_conf["status"], "Confirmed")
        self.assertIsNotNone(reg_conf["ticket_code"])
        ticket_code = reg_conf["ticket_code"]
        conn.close()

        # Test Ticket QR Code API
        tkt_qr = self.client.get(f"/api/ticket-qr/{ticket_code}")
        self.assertEqual(tkt_qr.status_code, 200)
        self.assertEqual(tkt_qr.mimetype, "image/png")

    def test_07_prevent_duplicate_utr_reuse(self):
        # Insert a new registration
        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO registrations (booking_reference, student_id, event_id, amount, status, upi_reference)
            VALUES ('CC-2026-TESTDUP', 3, 3, 150.0, 'Pending verification', 'UTR987654321012')
        """)
        dup_reg_id = cursor.lastrowid
        conn.commit()
        conn.close()

        # Login as Organizer
        self.client.post("/login", data={
            "email": "organizer@campusconnect.edu",
            "password": "Organizer@123"
        })

        # View dashboard - must show REUSED UTR DETECTED
        resp = self.client.get("/organizer/payments")
        self.assertIn(b"REUSED UTR DETECTED", resp.data)

        # Attempt to approve the duplicate UTR
        appr_resp = self.client.post(f"/organizer/payments/{dup_reg_id}/approve", follow_redirects=True)
        self.assertIn(b"was already verified", appr_resp.data)

        # Verify it was NOT approved
        conn = database.get_db_connection()
        dup_reg = conn.execute("SELECT status FROM registrations WHERE id = ?", (dup_reg_id,)).fetchone()
        self.assertNotEqual(dup_reg["status"], "Confirmed")
        conn.close()

if __name__ == "__main__":
    unittest.main()
